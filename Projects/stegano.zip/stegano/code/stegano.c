/*
 * stegano.c
 *
 *  Created on: Jun 8, 2015
 *      Authors: Yop Spanjers & Rafal Grasman
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "resource_detector.h"
#include "bit.h"
#include "header.h"
#include "stegano.h"

#define MAX_FILENAME 255

#define max(a,b)    (((a) > (b)) ? (a) : (b))

#ifdef _WIN32
#pragma pack (1)
#endif

typedef struct
{
	BMP_MAGIC_t magic;
	BMP_FILE_t file;
	BMP_INFO_t info;
}
#ifndef _WIN32
__attribute__((packed))
#endif
BMP_ALL;

typedef struct
{
	uint8_t c[3];
} 
#ifndef _WIN32
__attribute__((packed))
#endif
BMP_COLOR;

const unsigned int bitspp = 24;
const unsigned int bitspb = 8;

size_t customfsize(FILE* fp)
{
	if (fp == NULL)
	{
		return 0;
	}
	size_t curr = ftell(fp);
	fseek(fp, 0L, SEEK_END);
	size_t size = ftell(fp);
	fseek(fp, curr, SEEK_SET);

	return size;
}

void multiplex (const char* File0, const char* File1)
{
	FILE* FilePtr[3]			=	{ NULL, NULL, NULL };

	BMP_ALL bmp[3];
	memset(bmp, 0, sizeof(bmp));

    char  buf[MAX_FILENAME];

	//prepare input files
	FilePtr[0]					=	fopen(File0, "rb"); //waarin je wilt verbergen
	FilePtr[1]					=	fopen(File1, "rb"); //wat wil je verbergen

	//prepare headers and load file 1 and 2 into memory in one big swing, nice performance gain (we assume enough free memory)
	//also do some housekeeping
	for (int i = 0; i < 2; ++i)
	{
		readHdr(FilePtr[i], &bmp[i].magic, &bmp[i].file, &bmp[i].info);
		fseek(FilePtr[i], bmp[i].file.bmp_offset, SEEK_SET);
	}

	memcpy(&bmp[2], &bmp[0], sizeof(BMP_ALL));

	//prepare memory
	size_t BitmapSizes[3];
	BMP_COLOR *FileBytes[3];

	BMP_COLOR nullColor;
	memset(&nullColor, 0, sizeof(nullColor));

	for (int i = 0; i < 3; ++i)
	{
		BitmapSizes[i] = sizeof(uint8_t) * (bitspp / bitspb) * bmp[i].info.width * bmp[i].info.height;
		FileBytes[i] = malloc(BitmapSizes[i]);
		if (i != 2)
		{
			if(fread(FileBytes[i], BitmapSizes[i], 1, FilePtr[i]))
			{ }
			fclose(FilePtr[i]);
		}
	}

    for (int NrBits = 0; NrBits < 9; NrBits++)
    {
        // NrBits: nbr of bits for the hidden image

		//prepare output file
        snprintf (buf, MAX_FILENAME, "mux_%s_%s_%d.bmp", File0, File1, NrBits);
        FilePtr[2] = fopen (buf,   "wb");

		//write the header
		bmp[2].info.nimpcolors = NrBits;
		bmp[2].file.creator1 = bmp[1].info.width;
		bmp[2].file.creator2 = bmp[1].info.height;

		writeHdr(FilePtr[2], &bmp[2].magic, &bmp[2].file, &bmp[2].info);
		
		memset(FileBytes[2], 0, BitmapSizes[2]);

		for (int32_t x = 0; x < bmp[2].info.width; ++x)
		{
			for (int32_t y = 0; y < bmp[2].info.height; ++y)
			{				
				BMP_COLOR src[2];
				BMP_COLOR steganoColor;

				memcpy(&src[0], (x < bmp[0].info.width) ? ((y < bmp[0].info.height) ? (&FileBytes[0][y * bmp[0].info.width + x]) : (&nullColor)) : (&nullColor), sizeof(BMP_COLOR));
				memcpy(&src[1], (x < bmp[1].info.width) ? ((y < bmp[1].info.height) ? (&FileBytes[1][y * bmp[1].info.width + x]) : (&nullColor)) : (&nullColor), sizeof(BMP_COLOR));

				for (int32_t z = 0; z < 3; ++z)
				{
					steganoColor.c[z] = getSubstring(src[0].c[z], NrBits, bitspb - NrBits, NrBits) | getSubstring(src[1].c[z], bitspb - NrBits, NrBits, 0);
				}

				memcpy(&FileBytes[2][y * bmp[2].info.width + x], &steganoColor, sizeof(steganoColor));
			}
		}

		//write our new bmp image:
		if(fwrite(FileBytes[2], BitmapSizes[2], 1, FilePtr[2])) { }

		//close output file
		fclose(FilePtr[2]);
    }

	for (int i = 0; i < 3; ++i)
	{
		free(FileBytes[i]);
	}
}

uint8_t reverse(uint8_t b)
{
	b = (b & 0xF0) >> 4 | (b & 0x0F) << 4;
	b = (b & 0xCC) >> 2 | (b & 0x33) << 2;
	b = (b & 0xAA) >> 1 | (b & 0x55) << 1;
	return b;
}

void multiplexText (const char* File0, const char* File1)
{
	FILE* FilePtr[3]			=	{ NULL, NULL, NULL };

	BMP_ALL bmp;
	memset(&bmp, 0, sizeof(bmp));

    char  buf[MAX_FILENAME];

	//prepare input files
	FilePtr[0]					=	fopen(File0, "rb");
	FilePtr[1]					=	fopen(File1, "rb");

	//prepare headers and load file 1 and 2 into memory in one big swing, nice performance gain (we assume enough free memory)
	//also do some housekeeping
	readHdr(FilePtr[0], &bmp.magic, &bmp.file, &bmp.info);
	fseek(FilePtr[0], bmp.file.bmp_offset, SEEK_SET);

	//prepare memory
	size_t FileSizes[2] = 
	{ 
		sizeof(uint8_t) * (bitspp / bitspb) * bmp.info.width * bmp.info.height,  
		customfsize(FilePtr[1])
	};

	uint8_t *FileBytes[3];

	//read files into memory & close
	for (int i = 0; i < 2; ++i)
	{
		FileBytes[i] = malloc(FileSizes[i]);
		if (fread(FileBytes[i], FileSizes[i], 1, FilePtr[i])){}
	}

	//prepare out file
    snprintf (buf, MAX_FILENAME, "mux_%s_%s.bmp", File0, File1);
    FilePtr[2] = fopen (buf,   "wb");

	//write the header
	bmp.file.creator1 = (uint16_t)FileSizes[1];

	writeHdr(FilePtr[2], &bmp.magic, &bmp.file, &bmp.info);

	for (size_t i = 0; i < FileSizes[0]; ++i)
	{
		size_t bindex = i / (bitspb * sizeof(uint8_t));
		if (bindex < FileSizes[1])
		{	
			uint8_t bit = (uint8_t)(i % (size_t)(bitspb * sizeof(uint8_t)));
			uint8_t character = FileBytes[1][bindex];
			uint8_t charbit = (character & (1 << bit)) >> bit;

			FileBytes[0][i] = (FileBytes[0][i] & ~1) | charbit;
		}
		else
		{
			FileBytes[0][i] = FileBytes[0][i];
		}
	}

	//write our new bmp image:
	if(fwrite(FileBytes[0], FileSizes[0], 1, FilePtr[2])) { }

	//close handles & cleanup
	for (int i = 0; i < 3; ++i)
	{
		fclose(FilePtr[i]);
		if (i != 2)
		{
			free(FileBytes[i]);
		}
	}
}

void demultiplex (const char* File0, const char* File1, const char* File2)
{
	FILE* FilePtr[3] = { NULL, NULL, NULL };

	BMP_ALL bmp;
	memset(&bmp, 0, sizeof(bmp));

	//prepare input file
	FilePtr[0] = fopen(File0, "rb");

	//...and output files
	FilePtr[1] = fopen(File1, "wb");
	FilePtr[2] = fopen(File2, "wb");

	//prepare header and load file 1 into memory in one big swing, nice performance gain (we assume enough free memory)
	//also do some housekeeping

	readHdr(FilePtr[0], &bmp.magic, &bmp.file, &bmp.info);
	fseek(FilePtr[0], bmp.file.bmp_offset, SEEK_SET);

	//todo: use hidden image width & height (creator1 & creator2) to make correct image size
	size_t BitmapSize = sizeof(uint8_t) * (bitspp / bitspb) * bmp.info.width * bmp.info.height;
	uint8_t *FileBytes[3] = { malloc(BitmapSize), malloc(BitmapSize), malloc(BitmapSize) };

	if (fread(FileBytes[0], BitmapSize, 1, FilePtr[0])){}

	int NrBits = bmp.info.nimpcolors;

	//write headers
	bmp.file.creator1 = 0;
	bmp.file.creator2 = 0;
	bmp.info.nimpcolors = 0;

	writeHdr(FilePtr[1], &bmp.magic, &bmp.file, &bmp.info);
	writeHdr(FilePtr[2], &bmp.magic, &bmp.file, &bmp.info);

	memset(FileBytes[1], 0, BitmapSize);
	memset(FileBytes[2], 0, BitmapSize);

	for (size_t i = 0; i < BitmapSize; ++i)
	{
		FileBytes[1][i] = getSubstring(FileBytes[0][i], NrBits, bitspb - NrBits, NrBits);
		FileBytes[2][i] = getSubstring(FileBytes[0][i], 0, NrBits, bitspb - NrBits);
	}

	for (int i = 0; i < 3; ++i)
	{
		if (i != 0)//write our new bmp images:
		{
			if (fwrite(FileBytes[i], BitmapSize, 1, FilePtr[i])) {}
		}
		//close output files and free memory
		fclose(FilePtr[i]);
		free(FileBytes[i]);
	}
}

void demultiplexText (const char* File0, const char* File1, const char* File2)
{
	FILE* FilePtr[3] = { NULL, NULL, NULL };

	BMP_ALL bmp;
	memset(&bmp, 0, sizeof(bmp));

	//prepare files
	FilePtr[0] = fopen(File0, "rb");
	FilePtr[1] = fopen(File1, "wb");
	FilePtr[2] = fopen(File2, "wb");

	//prepare headers and load file 1 into memory in one big swing, nice performance gain (we assume enough free memory)
	//also do some housekeeping
	readHdr(FilePtr[0], &bmp.magic, &bmp.file, &bmp.info);
	fseek(FilePtr[0], bmp.file.bmp_offset, SEEK_SET);

	//prepare memory
	size_t FileSizes[3] =
	{
		sizeof(uint8_t) * (bitspp / bitspb) * bmp.info.width * bmp.info.height,
		sizeof(uint8_t) * (bitspp / bitspb) * bmp.info.width * bmp.info.height,
		bmp.file.creator1
	};

	uint8_t *FileBytes[3];

	//read files into memory & close
	for (int i = 0; i < 3; ++i)
	{
		FileBytes[i] = malloc(FileSizes[i]);
		memset(FileBytes[i], 0, FileSizes[i]);
	}

	if (fread(FileBytes[0], FileSizes[0], 1, FilePtr[0])) {}

	//write the header
	bmp.file.creator1 = 0;
	writeHdr(FilePtr[1], &bmp.magic, &bmp.file, &bmp.info);

	for (size_t i = 0; i < FileSizes[0]; ++i)
	{
		size_t bindex = i / (bitspb * sizeof(uint8_t));
		if (bindex < FileSizes[2])
		{
			uint8_t bit = (uint8_t)(i % (size_t)(bitspb * sizeof(uint8_t)));
			uint8_t charbit = (FileBytes[0][i] & 1) << bit;

			FileBytes[2][bindex] |= charbit;
			FileBytes[1][i] = FileBytes[0][i] & ~1;
		}
		else
		{
			FileBytes[1][i] = FileBytes[0][i];
		}
	}

	//write our data:
	if (fwrite(FileBytes[1], FileSizes[1], 1, FilePtr[1])) {}
	if (fwrite(FileBytes[2], FileSizes[2], 1, FilePtr[2])) {}

	//close handles & cleanup
	for (int i = 0; i < 3; ++i)
	{
		fclose(FilePtr[i]);
		free(FileBytes[i]);
	}
}

